chrome.runtime.onInstalled.addListener(function() {
    chrome.storage.sync.clear();
  });
  
  chrome.runtime.onStartup.addListener(function() {
    chrome.storage.sync.get(['username', 'loginTime'], function(data) {
      if (data.username && data.loginTime) {
        const loginTime = new Date(data.loginTime);
        const now = new Date();
        if ((now - loginTime) >= 24 * 60 * 60 * 1000) {
          chrome.storage.sync.remove(['username', 'loginTime']);
        }
      }
    });
  });
  