document.addEventListener('DOMContentLoaded', function() {
    const loginSection = document.getElementById('login-section');
    const walletSection = document.getElementById('wallet-section');
    const loginButton = document.getElementById('login-button');
    const registerButton = document.getElementById('register-button');
    const addWalletButton = document.getElementById('add-wallet-button');
    const logoutButton = document.getElementById('logout-button');
    const userNameSpan = document.getElementById('user-name');
  
    // Check if user is already logged in
    chrome.storage.sync.get(['username', 'loginTime'], function(data) {
      if (data.username && data.loginTime) {
        const loginTime = new Date(data.loginTime);
        const now = new Date();
        if ((now - loginTime) < 24 * 60 * 60 * 1000) { // Check if login is within 24 hours
          loginSection.style.display = 'none';
          walletSection.style.display = 'block';
          userNameSpan.textContent = data.username;
        } else {
          chrome.storage.sync.remove(['username', 'loginTime']);
        }
      }
    });
  
    loginButton.addEventListener('click', function() {
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      // Perform login (simple example, should use proper authentication in a real-world app)
      if (username && password) {
        chrome.storage.sync.set({username: username, loginTime: new Date().toString()}, function() {
          loginSection.style.display = 'none';
          walletSection.style.display = 'block';
          userNameSpan.textContent = username;
        });
      }
    });
  
    registerButton.addEventListener('click', function() {
      // Registration logic (similar to login)
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      if (username && password) {
        // Save user data (simplified for example)
        chrome.storage.sync.set({username: username, password: password});
        alert('Registered successfully. You can now log in.');
      }
    });
  
    addWalletButton.addEventListener('click', function() {
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const activeTab = tabs[0];
        chrome.scripting.executeScript({
          target: {tabId: activeTab.id},
          func: checkBankSite
        });
      });
    });
  
    logoutButton.addEventListener('click', function() {
      chrome.storage.sync.remove(['username', 'loginTime'], function() {
        loginSection.style.display = 'block';
        walletSection.style.display = 'none';
      });
    });
  });
  
  function checkBankSite() {
    const bankSites = ['bank.com', 'finance.com']; // Add more bank domains
    const currentSite = window.location.hostname;
    const bankNameElement = document.querySelector('.bank-name'); // Example selector for bank name
  
    if (bankSites.some(site => currentSite.includes(site)) && bankNameElement) {
      const bankName = bankNameElement.textContent;
      chrome.storage.sync.set({bankName: bankName}, function() {
        alert(`Bank ${bankName} added to wallet`);
      });
    } else {
      alert('Not a bank site or unable to detect bank name');
    }
  }
  